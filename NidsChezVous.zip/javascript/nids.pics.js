/*global jQuery, window, document, self, _gaq, Drupal, google */
(function($) {

  Drupal.behaviors.nids_map = {

    map: {}, map_center: {}, marker_icon: {}, polygon_icon: {},
    markers: [], polygons: [], polygon_vertices: [],
    geography: "", infowindows: [], val: [],

    attach: function() {
      this.attachEvents();
    },

    attachEvents: function() {
      polygon = {};
      $("[name^=espece_]").change(function() {
        var self=this;
        bid=$(this).attr('name').replace('espece_', '');
        bid=bid.replace('[]','');
        val=this.value;
        $.ajax({
          url: "nids/oiseaux_pics",
          data: { oiseau : val},
          type: "POST",
          success: function(result){
              link=result['link'].replace('orig','580_360')
              $('#photodiv'+bid).html('<a href="'+result['link']+'" target="_blank"><img src="'+link+'" style="height:200px;"></a><br><strong><a href="'+result['info']+'" target="_blank">'+val+': Informations</strong></a>')
          }
        });
      });
    }
  };

}(jQuery));